import time
from funcs import RandomArray
from funcs import MergeSort
#Generate Random numbers
arr = RandomArray(30000)
#Take starting and ending index to apply merge sort
start = int(input("Enter starting index "))
end = int(input("Enter ending index "))
s = time.time()
MergeSort(arr,start,end)
e = time.time()
#print(arr[start:end:1])
print(arr)
run = e - s
print("Runtime of merge sort in seconds is: ",run)

#to write the sorted portion of array in text file
s = (arr[start:end:1]) 
file = open("SortedMergeSort.csv",mode = "w")
for i in s:
    file.write(str(i)+"\n")