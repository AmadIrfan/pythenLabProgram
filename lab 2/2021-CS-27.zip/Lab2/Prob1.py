from funcs import RandomArray

print(RandomArray(9))