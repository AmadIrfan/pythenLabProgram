import pandas as pd


df=pd.read_csv('Test.csv')
df1=pd.read_csv("Train.csv")
print(df.dtypes)
print(df1.dtypes)