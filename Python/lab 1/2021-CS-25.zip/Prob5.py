


from Funcs import StringReverse
str="University of Engineering and Tecnology Lahore" 

start=input('Enter Starting index : ')
starting=int(start)
end=input('Enter Ending index : ')
ending=int(end)



string = StringReverse(str,starting,ending)
print(string)
